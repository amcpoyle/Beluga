"""Check a converted model against the FMU it came from.

    python -m omc2casadi.check path/to/Model.fmu [--info Model_info.json] [--points 200] [--spread 0.3]
                               [--linear-solver lapacklu [--min-size 20]]

The FMU (Model Exchange 2.0, built by OpenModelica with directional derivatives) is evaluated through CasADi's
FmuFunction, the converted model through omc2casadi; both get the same states and inputs. States are the
FMU's start values plus random perturbations (spread x max(|start|, nominal)), inputs standard normal. Reports
the worst relative difference of the state derivatives, the outputs and the Jacobian (relative to each
quantity's largest magnitude over the sample). A correct conversion agrees to ~1e-12 or better; the FMU
evaluates the same equations in the same order, so larger differences mean a conversion error. Build the FMU
with -d=-disableDirectionalDerivatives (as the regression suite does) for an exact reference Jacobian;
without it the FMU's Jacobian is finite differences and only checked to TOL_FD_JACOBIAN.
linear_solver / --linear-solver checks the conversion with OmcModel.function's numeric solves of the large linear
systems: the symbolic solves have no pivoting, and on badly conditioned systems they lose digits that the
FMU's pivoted LAPACK solves keep (README, known weak spots).
"""
import argparse
import os
import xml.etree.ElementTree as ET
import zipfile

import casadi as ca
import numpy as np

from .model import OmcModel

TOL = 1e-9  # pass/fail threshold on the relative differences
# FMUs without directional derivatives: CasADi finite-differences the FMU, so its Jacobian is only this good
TOL_FD_JACOBIAN = 1e-4


def exact_jacobian(unz):
    """Whether the unzipped FMU provides directional derivatives (else CasADi finite-differences it)."""
    md = ET.parse(os.path.join(unz, "modelDescription.xml")).getroot().find("ModelExchange")
    return md is not None and md.get("providesDirectionalDerivative") == "true"


def passed(res, exact):
    """compare() result within tolerance: TOL, and TOL_FD_JACOBIAN for a finite-difference FMU Jacobian."""
    return all(v <= (TOL_FD_JACOBIAN if k == "jacobian" and not exact else TOL)
               for k, v in res.items() if k != "points")


def load(fmu_path, info_json=None):
    """(OmcModel, unzipped FMU directory). info_json defaults to <fmu without .fmu>_info.json."""
    model = OmcModel.from_fmu(fmu_path, info_json)
    unz = os.path.splitext(fmu_path)[0] + "_unz"
    if not os.path.isdir(unz) or os.path.getmtime(unz) < os.path.getmtime(fmu_path):
        with zipfile.ZipFile(fmu_path) as z:
            z.extractall(unz)
        os.utime(unz)
    return model, unz


def compare(f_ref, f_conv, X, U, names, n_jac=10, verbose=True):
    """Evaluate both functions (same signature (x, u) -> outputs) at the rows of X, U. names: per output
    block, the list of entry names. Returns {block: max relative difference, "jacobian": ...}."""
    nout = f_ref.n_out()
    ref = [[] for _ in range(nout)]
    conv = [[] for _ in range(nout)]
    keep = []
    for k in range(len(X)):
        try:
            r = [np.array(v).ravel() for v in f_ref.call([X[k], U[k]])]
        except RuntimeError:  # the FMU may reject a state (assert); skip it
            continue
        if not all(np.all(np.isfinite(v)) for v in r):
            continue
        c = [np.array(v).ravel() for v in f_conv.call([X[k], U[k]])]
        for i in range(nout):
            ref[i].append(r[i])
            conv[i].append(c[i])
        keep.append(k)
    if not keep:
        raise RuntimeError("the FMU rejected every sample point")
    out = {"points": len(keep)}
    for i in range(nout):
        a, b = np.array(ref[i]), np.array(conv[i])
        if a.size == 0:
            continue
        scale = np.maximum(np.abs(a).max(axis=0), 1e-12)
        e = np.abs(a - b) / scale
        label = f_ref.name_out(i)
        out[label] = float(e.max())
        if verbose:
            worst = np.argsort(-e.max(axis=0))[:3]
            print(f"  {label:9s} max relative difference {e.max():.1e}; worst: "
                  + ", ".join(f"{names[i][j]} {e[:, j].max():.1e}" for j in worst))
    # Jacobians: the FMU's directional derivatives vs CasADi AD
    nx, nu = f_ref.size1_in(0), f_ref.size1_in(1)
    xs, us = ca.MX.sym("x", nx), ca.MX.sym("u", nu)
    xu = ca.vertcat(xs, us)
    Jr = ca.Function("Jr", [xs, us], [ca.jacobian(ca.vertcat(*f_ref.call([xs, us])), xu)])
    Jc = ca.Function("Jc", [xs, us], [ca.jacobian(ca.vertcat(*f_conv.call([xs, us])), xu)])
    errs = []
    for k in np.array(keep)[np.linspace(0, len(keep) - 1, min(n_jac, len(keep))).astype(int)]:
        a, b = np.array(Jr(X[k], U[k])), np.array(Jc(X[k], U[k]))
        errs.append(np.abs(a - b).max() / max(np.abs(a).max(), 1e-12))
    out["jacobian"] = float(max(errs))
    if verbose:
        print(f"  jacobian  max relative difference {out['jacobian']:.1e} over {len(errs)} points")
    return out


def check_fmu(fmu_path, info_json=None, points=200, spread=0.3, seed=0, verbose=True, linear_solver=None,
              min_size=20):
    """Convert the model behind an FMU and compare it with the FMU. Returns the compare() dict plus "ok".
    linear_solver, min_size: passed to OmcModel.function (None = all solves symbolic)."""
    model, unz = load(fmu_path, info_json)
    dae = ca.DaeBuilder(os.path.basename(os.path.splitext(fmu_path)[0]), unz)
    xs, us, ys = list(dae.x()), list(dae.u()), list(dae.y())
    if set(xs) != set(model.states):
        raise ValueError(f"state sets differ between the FMU and the JSON: {sorted(set(xs) ^ set(model.states))[:6]}")
    outs = ["ode", "y"] if ys else ["ode"]
    f_ref = dae.create("fmu", ["x", "u"], outs)
    f_conv = model.function("conv", outputs=ys if ys else False, states=xs, inputs=us, linear_solver=linear_solver,
                            min_size=min_size)
    if verbose:
        print(f"{os.path.basename(fmu_path)}: {len(xs)} states, {len(us)} inputs, {len(ys)} outputs; "
              f"{f_conv.n_nodes()} SX nodes, {len(model.used_blocks)} of {len(model.blocks)} equation blocks used")

    def start(n):
        v = np.ravel(dae.start(n))
        return float(v[0]) if v.size else 0.0

    x0 = np.array([start(n) for n in xs])
    nominal = np.array([float(np.ravel(dae.nominal(n))[0]) if np.size(dae.nominal(n)) else 1.0 for n in xs])
    rng = np.random.default_rng(seed)
    X = x0 + rng.normal(size=(points, len(xs))) * spread * np.maximum(np.abs(x0), nominal)
    X[0] = x0
    U = rng.normal(size=(points, len(us)))
    names = [["der(" + n + ")" for n in xs], ys]
    res = compare(f_ref, f_conv, X, U, names, verbose=verbose)
    exact = exact_jacobian(unz)
    res["ok"] = passed(res, exact)
    res["exact_jacobian"] = exact
    if verbose:
        print(f"  {'PASS' if res['ok'] else 'FAIL'} ({res['points']} points, tolerance {TOL:g}"
              + ("" if exact else f"; the FMU has no directional derivatives, so its Jacobian is finite "
                                  f"differences: tolerance {TOL_FD_JACOBIAN:g}") + ")")
    return res


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("fmu")
    ap.add_argument("--info", default=None, help="<model>_info.json (default: next to the FMU)")
    ap.add_argument("--points", type=int, default=200)
    ap.add_argument("--spread", type=float, default=0.3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--linear-solver", default=None, help="e.g. lapacklu: numeric solves of large linear systems")
    ap.add_argument("--min-size", type=int, default=20, help="smallest linear system solved numerically")
    a = ap.parse_args()
    res = check_fmu(a.fmu, a.info, a.points, a.spread, a.seed, linear_solver=a.linear_solver, min_size=a.min_size)
    raise SystemExit(0 if res["ok"] else 1)


if __name__ == "__main__":
    main()
