"""OpenModelica -> CasADi SX: builds CasADi Functions from the solved equations in <model>_info.json."""
from .model import OmcModel
