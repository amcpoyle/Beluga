# omc2casadi: OpenModelica models as CasADi SX

`omc2casadi` turns a Modelica model, compiled by OpenModelica (OMC), into a CasADi **SX** function
`f(x, u[, p]) -> (xdot, y)`. You don't port anything by hand. The function is a symbolic expression graph,
so CasADi (and anything built on it, such as IPOPT NLPs or acados) gets exact first and second derivatives
by automatic differentiation. With the FMU you only get first derivatives and a black box.

The converter does not interpret Modelica. OMC has already done the hard work (flattening, index reduction,
matching, sorting, tearing, alias elimination) and records the result in `<Model>_info.json`. The converter
reads that file and replays OMC's solved equations on CasADi symbols.

**Rule for this package:** the goal is a general, automatic Modelica → CasADi path for models of any size. Don't
port models by hand, and don't add per-model special cases. The package depends only on `casadi` and `numpy`
(plus OpenModelica to build FMUs and run the tests) and imports nothing else from this repo; model-specific code
belongs to its user. In this repo that is [`omc2casadi_opt/`](../omc2casadi_opt/README.md) (lap-time
optimization of AlyssaVehicle), which keeps the FMU path (`fmu_opt/`) working alongside it.

---

## Quick reference

```python
from omc2casadi import OmcModel

m = OmcModel.from_fmu("path/MyModel.fmu")               # reads path/MyModel_info.json next to it
f = m.function()                                        # f(x, u) -> (ode, y), FMU state/input/output order
f = m.function(overrides={"some.param": 2.0})           # independent-parameter overrides (numbers)
f = m.function(symbolic_params=["some.param"])          # f(x, u, p): parameter kept as an SX input
f = m.function(outputs=["vxBody"], states=[...], inputs=[...])   # choose and order the arguments
m.states, m.inputs, m.outputs                           # names in FMU order
```

```
python -m omc2casadi.check path/Model.fmu      # compare a conversion with its FMU (any OMC FMU)
python -m pytest omc2casadi/tests -v           # regression suite (builds the MSL test FMUs on first run)
```

Example user: `omc2casadi_opt/vehicle_casadi.VehicleCasadi` wraps `OmcModel.function()` as the lap-time
vehicle; `python -m omc2casadi_opt.check_alyssa` checks that conversion against its FMU.

### Producing the inputs

Build an FMU with OMC. That one build writes all three files the converter needs:

```
loadModel(Modelica, {"4.0.0"});
loadFile("MyModel.mo");
setCommandLineOptions("-d=-disableDirectionalDerivatives");   // exact FMU Jacobians, for the check
buildModelFMU(MyModel, version="2.0", fmuType="me", fileNamePrefix="MyModel", platforms={"static"});
```

| File | Written by | Used for |
|---|---|---|
| `MyModel_info.json` | OMC, next to the FMU | the equations (the only source of the dynamics) |
| `MyModel.fmu` → `modelDescription.xml` | inside the FMU | inputs, outputs, state order, parameter start values |
| `MyModel.fmu` → `sources/MyModel_init_fmu.c` | inside the FMU | start values of **every** variable (the XML leaves some out) |

The JSON and the FMU must come from the same build; nothing in the files ties them together, so ship and
update them as a pair.

---

## Files

| File | Contents |
|---|---|
| `expr.py` | tokenizer, recursive-descent parser for OMC's expression strings, and an evaluator that works on floats, SX and numpy object arrays |
| `functions.py` | CasADi/numpy versions of Modelica library functions that OMC leaves as calls, plus the built-in array functions |
| `model.py` | `OmcModel`: loading, `Block`s, dependency slicing, parameter/initialization evaluation, building the `ca.Function` |
| `check.py` | `check_fmu()` / `compare()`: converted model vs FMU (derivatives, outputs, Jacobian); command-line interface |
| `tests/test_expr.py` | parser and evaluator unit tests |
| `tests/test_models.py` | regression suite: MSL examples against their FMUs; FMUs are cached in `tests/_build/` (gitignored) |

---

## How it works

```
OmcModel.__init__
  read modelDescription.xml       -> inputs, outputs, state order, parameter starts (self.start)
  read _init_fmu.c (optional)     -> start values of all variables (self.start_values)
  _blocks("parameter")            -> self.param_blocks
  _blocks("regular")              -> self.blocks         (each JSON entry: parse strings -> AST -> Block)

OmcModel.function(...)
  1. env = {state: x[k], input: u[k], "time": 0}
  2. _needed(self.blocks, targets = $DER.<state> + outputs)  -> needed blocks, missing names
  3. missing names are parameters: parameters() (starts + overrides / SX symbols)
     -> _needed(param_blocks, missing) -> run them
     -> still missing (fixed=false parameters, pre()): _initialization() runs the start + initial sections
  4. _run(needed blocks, env) on SX           -> env[$DER.<state>], env[<output>]
  5. ca.Function(name, [x, u(, p)], [ode(, y)])
```

### Parsing (`expr.py`)

- `parse(text)` returns an AST of plain tuples (node types are listed in the module docstring).
  Precedence follows the Modelica grammar. A unary minus applies to a whole term (`-2^2 == -4`).
- **Names are canonical strings.** A dotted name with literal subscripts becomes a single string,
  `a.b[1].c[2,3]`, exactly the scalarized names used as keys in the JSON. Non-literal subscripts
  become an `("index", ...)` node instead.
- `der(x)` → name `$DER.x`, and `der(der(x))` → `$DER.$DER.x`, matching the `$DER.` form OMC uses
  inside expressions. In `defines` lists OMC writes `der(x)`, which `canonical_der()` normalizes.
- `pre(x)` → name `$PRE.x` (event memory; see Initialization).
- C-style comments are skipped (OMC writes casts such as `/*Real*/(x)`).
- `free_names(ast)` lists the names an expression uses; slicing is built on it.

### Evaluation (`expr.evaluate`)

One tree walk serves both numeric parameters and the symbolic dynamics:

- Values are Python numbers, `ca.SX` scalars, or **numpy object arrays** (Modelica arrays). Build arrays with
  `objarray()`, because `np.array(list_of_SX)` tries to iterate SX.
- Modelica `*` is `_mul`: vector·vector is a dot product, a matrix with a vector or matrix is a matrix
  product, a scalar is elementwise.
- `if`: a numeric condition picks a branch; a symbolic one becomes `ca.if_else`.
- `noEvent`, `smooth`, `homotopy(actual, simplified)` → the plain value / `actual`.
- Functions are looked up in `LIBRARY` (functions.py) and then `BUILTINS`. An unknown function raises
  `NotImplementedError("function ... has no implementation")`.

### Blocks (`model.OmcModel._blocks`)

Each top-level entry of a section becomes one `Block(eq, kind, defines, asts, children)`. `Block.uses`
holds the names it reads, minus the ones it defines itself (including those of its torn children).

| JSON tag | Block kind | Evaluation in `_run` |
|---|---|---|
| `assign` | `assign` | `env[define] = evaluate(expr)` |
| `system`, `display: "linear"` | `linear` | build SX matrix A (n×n) and vector b, `x = ca.solve(A, b)`, `env[defines[k]] = x[k]` |
| `tornsystem`, `display: "linear"` | `torn` | see below |
| `alias` | (resolved) | the entry stands for equation `equation[0]`, usually in another section; `_resolve` follows it |
| `algorithm`, `dummy` | skipped | in every model tested, these are `assert(...)` |
| `system`/`tornsystem` with `display` other than `linear` | — | **`NotImplementedError`** (nonlinear algebraic system) |

**Torn linear systems.** The tornsystem's `defines` are the *tearing variables*. Child entries (with
`"parent": <eqIndex>`) are tagged `torn` (assignments of the other unknowns, written in terms of the
tearing variables), `residual` (expressions that must vanish) or `jacobian` (OMC's numerical Jacobian,
ignored). `_run`:

1. replaces the tearing variables with fresh SX symbols `z`;
2. runs the torn assignments in a copy of the environment;
3. stacks the residuals `r(z)` and checks that `J = jacobian(r, z)` doesn't depend on `z`
   (otherwise it raises: the system is not linear);
4. solves `z* = -J⁻¹ r(0)`;
5. substitutes `z*` into every torn variable.

### Slicing (`_needed`)

Starting from the target names, the code finds the block that defines each name and queues that block's
`uses`, until nothing new is added. A name that is a *base* of defined elements (`v` when `v[1]`, `v[2]`
are defined) expands to those elements. Names nothing defines are returned as `missing`. Only the
needed blocks are evaluated: in AlyssaVehicle, 355 of 612. That's what drops visualization, asserts and
OMC's Jacobian equations without having to support the functions they call.

### Parameters and initialization

- `parameters(overrides, symbolic)`: start values of the **independent** parameters
  (`causality="parameter"` in the XML), plus overrides. Overriding a calculated parameter raises an
  error, because the parameter section would silently recompute it. Names in `symbolic` become SX symbols
  and form the function's `p` input.
- The `parameter` section (a sliced subset) computes the calculated parameters from them, numerically or
  symbolically.
- `_initialization(names, params)` handles what the parameter section doesn't define: `fixed=false`
  parameters (e.g. a rod length computed from the initial geometry) and `pre()` values. It runs the
  `start` section (which defines some `$START.x` from expressions) and the `initial` section numerically,
  as the FMU does when it initializes:
  - known beforehand: parameters, `$START.<v>` for every start value, inputs at their start values,
    `time = 0`. OMC's initial equations then assign everything else (fixed variables from `$START.x`).
  - a missing `$START.x` or `$PRE.x` takes x's start value, or 0, Modelica's default start.
- **`pre()` in the dynamics** (e.g. which root of an analytic loop solution applies) is frozen at x's value
  after initialization, which matches an FMU evaluated without event handling. `function()` emits a
  `UserWarning` naming the frozen variables (also stored in `m.frozen_pre`). It's valid as long as the
  trajectory stays on that branch.

---

## Facts about OMC's `_info.json` (OMC 1.25.4)

Collected while building this converter. The format is OMC-internal (it feeds OMEdit's Transformational
Debugger) and undocumented, so pin the OMC version and re-run the regression suite after upgrading.

- Top-level keys: `format`, `version`, `info`, `variables`, `equations`, `functions`.
- `variables[name].kind`: `state`, `derivative`, `variable`, `parameter`, `constant`, `discrete`,
  `dummy state`, `dummy derivative`, `jacobian variable`, `jacobian differentiated variable`.
- `equations[i]`: `eqIndex`, `section`, `tag`, and depending on the tag `defines`, `uses`, `equation`,
  `parent`, `display`, `unknowns`, `source`.
  - Sections: `regular` (the ODE right-hand side and outputs, in evaluation order), `parameter`,
    `initial`, `start`, `nominal`, `jacobian` (OMC's symbolic Jacobians; not needed).
  - `equation` is a list of strings (an expression in Modelica syntax) for `assign`/`torn`/`residual`;
    a list holding one equation index for `alias`; and for `system` a list holding one
    `{"size", "density", "A": [{"row", "column", "exp"}], "b": [exp, ...]}` (0-based rows and columns).
  - `uses` lists are not relied on; dependencies are computed from the parsed expressions.
- OMC-internal names: `$cse<n>` (common subexpressions, defined by regular `assign`s), `$DER.x`,
  `$START.x`, `$TMP$VAR$...`, `$STATESET<n>` (dynamic state selection, e.g. quaternions; it appears
  inside nonlinear systems), and the function `$_signNoNull(x)` (sign, +1 at 0).
- The `functions` key lists only names (no bodies). Most user and MSL functions are inlined into the
  equations; the rest need an entry in `functions.py`.
- `modelDescription.xml` does **not** carry start values for every variable (e.g. dummy states such as
  Fourbar2's `j2.s`). `sources/<model>_init_fmu.c` does, as
  `modelData->realVarsData[i].info.name = "..."` / `.attribute.start = ...`. `_init_fmu_starts()` parses
  those lines.
- An FMU's directional derivatives exist only if it was built with `-d=-disableDirectionalDerivatives`
  (`providesDirectionalDerivative="true"` in the XML). Without them, CasADi's `FmuFunction`
  finite-differences the FMU, and its Jacobian is only accurate to about 1e-5.

---

## Validation

`check.check_fmu()` evaluates the FMU (through CasADi's `FmuFunction`) and the converted function at the
same random states (start values plus perturbations; the first point is the start state) with random
inputs, and compares:

- state derivatives and outputs: worst relative difference per quantity, scaled by the largest magnitude
  of that quantity over the sample;
- the Jacobian with respect to (x, u): FMU directional derivatives vs CasADi AD.

Pass threshold `TOL = 1e-9`. A correct conversion gives about 1e-14, because the FMU evaluates the
same equations in the same order. If the FMU has no directional derivatives, the Jacobian threshold is
`TOL_FD_JACOBIAN = 1e-4`, and the report says so. Points the FMU rejects (exceptions, non-finite values)
are skipped.

**Always run the check after converting a new or changed model.** Unsupported features raise an error,
but the check is what proves a converted model correct.

### Current status (MSL regression suite all passing, 2026-10-25)

| Model | Exercises | Result |
|---|---|---|
| AlyssaVehicle (`fmu/`, tested in `omc2casadi_opt/`) | planar joint chain, rack + tie rod loops (a 44-variable torn system), tire model | with `linear_solver="lapacklu"`: derivatives 7e-13 (lap states), 1e-11 (random states); all-symbolic only ~1e-5 (weak spot 3) |
| Pendulum, DoublePendulum | open chains | match |
| PendulumWithSpringDamper | spring visualization, `/*Real*/` casts | match |
| ForceAndTorque, RollingWheel | MultiBody forces; rolling contact | match |
| Fourbar2 | analytic loop: `fixed=false` rod length (initialization), `pre()` branch choice, `der(der())` | match (with the `pre()` warning) |
| Oscillator, ChuaCircuit | translational, electrical | match |
| FreeBody | quaternion free body → nonlinear system (`$STATESET`) | raises `NotImplementedError` (expected) |
| Fourbar1, EngineV6 | closed kinematic loops → nonlinear torn systems | raises `NotImplementedError` (expected) |

Timing (AlyssaVehicle, per point): the FMU takes 0.09 ms to evaluate and 0.20 ms per Jacobian. The SX
function compiled with gcc -O2 takes 0.002 ms to evaluate, 0.004 ms per Jacobian and 0.010 ms per exact
Hessian (the FMU's finite-difference Hessian takes 4.7 ms). On the Catalunya ds 10 lap-time OCP, the same
optimum (83.708394 s) was reached in 375 s of wall time instead of 658 s.

---

## Supported and unsupported

**Supported:** explicit assignments; linear systems (plain and torn); calculated and `fixed=false`
parameters; `noEvent`/`smooth` conditionals (as `if_else`); `pre()` frozen at its initialization value; the
functions in `functions.py` and `BUILTINS`; symbolic parameters.

**Unsupported, raises an error:**
- nonlinear algebraic systems: closed kinematic loops, quaternion bodies (dynamic state selection),
  implicit nonlinear equations;
- library functions without an implementation;
- names with no value anywhere (raises `KeyError`).

**Unsupported, with no symbolic form at all:** `when` clauses and discrete state updates, external C
functions (tire DLLs such as MF-Tyre, `CombiTable`), stick–slip friction and other event-driven behaviour.
Models meant for this converter should use smooth formulations, a Modelica-native tire model (as
AlyssaVehicle does), and joint chains or Cardan angles instead of quaternion free bodies
(`useQuaternions=false`).

Dymola: the converter needs OMC's `_info.json`. A Dymola model whose source OMC can load (plain Modelica,
no encrypted `.moe` libraries) can be compiled by OMC just for the conversion. A front end for Dymola's
`dsmodel.mof` listing (the same kind of information) is a possible future addition; it hasn't been tried.

---

## Known weak spots (open, ordered by risk)

The first three could give a **wrong model without an error**. The rest raise an error or affect speed.

1. **`time` is fixed at 0** (`function()`: `env["time"] = 0.0`). A time-dependent model (sources,
   time-varying tables) converts but is wrong for t ≠ 0. The FMU check can't detect it (`FmuFunction` also
   evaluates at t = 0). To do: raise an error, or make `time` an input, when a needed block uses `time`.
2. **Linear-system unknown order is assumed:** column k of A belongs to `defines[k]`. All tests agree, but
   the JSON doesn't state it.
3. **The symbolic solves have no numerical pivoting** (`ca.solve` on SX, linear and torn systems), whereas
   OMC's runtime uses LAPACK with pivoting. On AlyssaVehicle's large torn system this costs ~4 digits at
   random states (1e-5 vs the FMU). `function(linear_solver="lapacklu", min_size=n)` solves systems of >= n
   unknowns numerically with pivoting (exact AD through the solve, MX instead of SX); `check_fmu` and
   `python -m omc2casadi.check` take the same option.
4. Torn systems keep only `torn` and `residual` children; any other child kind is dropped (that should
   lead to a `KeyError`, not a wrong result).
5. Whole-array references to states or inputs (`x` for `x[1..n]`) are reported as missing parameters
   (an error).
6. An `assign` with several `defines` assumes the value flattens in the same order (not exercised).
7. `SX scalar * numpy array` in `_mul` depends on how CasADi handles operators (not exercised).
8. A numeric `if` evaluates every condition, even after a branch is taken. `_has`/`lookup_in` scan the
   whole environment on each array lookup, which is slow for very large models.

---

## Extending

- **Adding a library function:** implement it in `functions.py`, following the MSL source line by line.
  Write conditions with `expr._if` so they work on floats and SX. Register it in `LIBRARY` under its
  fully qualified name. Re-run the model's check.
- **Adding a test model:** add it to `CONVERTIBLE` (it must match its FMU) or `NONLINEAR` (it must raise) in
  `tests/test_models.py`. The fixture builds missing FMUs with directional derivatives.
- **Nonlinear systems (the next major feature):** two options, and the choice depends on where the model
  is used:
  - `ca.rootfinder` inside the function: exact derivatives through the implicit function theorem, but an
    MX construct, so it can't be used with acados or SX-only code generation;
  - **algebraic states z** with the residuals as implicit equations, i.e. output the DAE
    `F(xdot, x, z, u) = 0`. acados IRK and CasADi collocation support this natively (index 1), and it
    stays SX. This is the better fit for acados MPC.
  
  Both need an initial guess for z (start values, or the previous solution). When either works, move
  FreeBody, Fourbar1 and EngineV6 to `CONVERTIBLE`.
- **Changing the converter:** run `python -m pytest omc2casadi/tests -v` (about 15 s with cached FMUs).
  A change that alters any converted model by more than about 1e-12 is a bug.

## Lessons from building it

- Never trust that a conversion is right because it builds. Fourbar2 built cleanly and was off by 3%
  (it took the wrong root) until the start values came from `_init_fmu.c` and initialization ran OMC's
  equations from `$START` values only.
- `der(der(x))` must become `$DER.$DER.x`. A one-level rewrite silently broke second derivatives in
  MultiBody models (AlyssaVehicle has none, so its check couldn't catch it).
- Finite-difference reference Jacobians (FMUs built without directional derivatives) look like 1e-5
  "errors". Check `providesDirectionalDerivative` before blaming the converter.
- OMC's old `translateModelXML` / CasADi XML route doesn't work for MultiBody models (OMC fails on
  matrix-valued function calls such as `from_nxy`, and CasADi 3.7's `DaeBuilder` can't read the
  output). The `_info.json` route replaced it.
