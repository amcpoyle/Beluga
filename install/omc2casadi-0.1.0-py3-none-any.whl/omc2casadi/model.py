"""CasADi model from an OpenModelica <model>_info.json (sorted, solved equations) plus modelDescription.xml.

OMC writes <model>_info.json next to every simulation/FMU build. Its "regular" section is the ODE right-hand
side in evaluation order, after OMC's matching, sorting, tearing and alias elimination:
    assign      defines := expression
    system      linear system A x = b over its "defines", A and b given entry by entry
    tornsystem  torn linear system: the "torn" children compute the other unknowns from the tearing
                variables ("defines"), the "residual" children must vanish; "jacobian" children are OMC's
                numerical Jacobian of the residual and are not needed here
The "parameter" section computes the calculated parameters from the independent ones (start values in
modelDescription.xml).

OmcModel.function() evaluates only the equations that the requested derivatives and outputs depend on
(visualization, asserts etc. are skipped) and returns a CasADi SX Function.
"""
import json
import os
import re
import warnings
import xml.etree.ElementTree as ET
import zipfile

import casadi as ca
import numpy as np

from .expr import canonical_der, evaluate, free_names, objarray, parse
from .functions import LIBRARY, Record


class Block:
    """One step of the sorted equation system: defines some variables from others."""

    def __init__(self, eq, kind, defines, asts, children=None):
        self.eq, self.kind, self.defines = eq, kind, defines
        self.asts = asts
        self.children = children or []
        uses = set()
        for a in asts:
            free_names(a, uses)
        for c in self.children:
            uses |= c.uses
        self.uses = uses - set(defines) - {d for c in self.children for d in c.defines}

    def __repr__(self):
        return f"Block({self.eq}, {self.kind}, {self.defines[:3]}{'...' if len(self.defines) > 3 else ''})"


def _parse_list(strs, eq):
    try:
        return [parse(s) for s in strs]
    except SyntaxError as e:
        raise SyntaxError(f"equation {eq}: {e}") from None


def _library_classes(path):
    """Candidate Modelica classes stored in file `path` of a library in directory layout (the top directory
    is named "<Library>" or "<Library> <version>"), outermost first, from the path text alone: the file
    need not exist here (the info.json may come from another machine). E.g.
    .../Modelica 4.0.0+maint.om/Mechanics/MultiBody/Joints/Internal/RevoluteWithLengthConstraint.mo gives,
    among others, Modelica.Mechanics.MultiBody.Joints.Internal.RevoluteWithLengthConstraint."""
    parts = [p for p in re.split(r"[\\/]", path or "") if p]
    if not parts or not parts[-1].endswith(".mo"):
        return []
    parts[-1] = parts[-1][:-3]
    if parts[-1] == "package":
        parts.pop()
    return [".".join([parts[i].split(" ")[0]] + parts[i + 1:]) for i in range(len(parts))]


def _rename_calls(ast, rename):
    """AST with every ("call", name, args) renamed through rename(name)."""
    if isinstance(ast, tuple):
        if ast and ast[0] == "call":
            return ("call", rename(ast[1]), [_rename_calls(a, rename) for a in ast[2]])
        return tuple(_rename_calls(a, rename) for a in ast)
    if isinstance(ast, list):
        return [_rename_calls(a, rename) for a in ast]
    return ast


class OmcModel:
    def __init__(self, info_json, model_description, init_source=None):
        """model_description: path or open file of the FMU's modelDescription.xml (inputs, outputs, state
        order, parameter start values). init_source: path or open file of the FMU's
        sources/<model>_init_fmu.c, the start values of EVERY variable (modelDescription.xml leaves some out,
        e.g. dummy states); only needed for models with parameters computed at initialization."""
        with open(info_json, encoding="utf-8") as f:
            info = json.load(f)
        self.variables = info["variables"]
        self.model_name = info.get("info", {}).get("name", "")
        self.by_index = {e["eqIndex"]: e for e in info["equations"]}
        self.states = [n for n, v in self.variables.items() if v["kind"] == "state"]

        md = ET.parse(model_description).getroot()
        self.inputs, self.outputs = [], []
        self.start = {}         # independent parameters -> start value (what the FMU uses unless overridden)
        self.start_values = {}  # every variable with a start value
        for v in md.find("ModelVariables"):
            name, caus = v.get("name"), v.get("causality")
            if caus == "input":
                self.inputs.append(name)
            elif caus == "output":
                self.outputs.append(name)
            typ = v[0] if len(v) else None
            if typ is None or typ.get("start") is None:
                continue
            val = _start_value(typ)
            self.start_values[name] = val
            if caus == "parameter":
                self.start[name] = val
        self.complete_start_values = init_source is not None
        if init_source is not None:
            for name, val in _init_fmu_starts(init_source).items():
                self.start_values.setdefault(name, val)
        # FMU state order: modelDescription's ModelStructure/Derivatives lists der(x) in state order
        ders = md.find("ModelStructure/Derivatives")
        mv = list(md.find("ModelVariables"))
        if ders is not None:
            names = [mv[int(u.get("index")) - 1].get("name") for u in ders]
            self.states = [n[4:-1] if n.startswith("der(") else n for n in names]

        self.param_blocks = self._blocks("parameter")
        self.blocks = self._blocks("regular")
        self._init_blocks = None  # parsed on demand: only for parameters computed at initialization

    @classmethod
    def from_fmu(cls, fmu_path, info_json=None):
        """OmcModel of an OpenModelica FMU: modelDescription.xml and sources/*_init_fmu.c from inside the .fmu,
        info_json defaults to <fmu without .fmu>_info.json (OMC writes it next to the FMU)."""
        info_json = info_json or os.path.splitext(fmu_path)[0] + "_info.json"
        with zipfile.ZipFile(fmu_path) as z:
            init = [n for n in z.namelist() if n.startswith("sources/") and n.endswith("_init_fmu.c")]
            with z.open("modelDescription.xml") as md:
                if init:
                    with z.open(init[0]) as src:
                        return cls(info_json, md, src)
                return cls(info_json, md)

    # ------------------------------------------------------------------------------------ blocks
    def _resolve(self, e):
        while e["tag"] == "alias":  # the equation is the same as another one (usually in "initial")
            e = self.by_index[e["equation"][0]]
        return e

    def _parse(self, strs, e):
        """Parsed expressions of equation e. A function declared inside a model class appears under OMC's
        instance-qualified name (<model>.<instance path>.<function>); it is renamed to the LIBRARY entry
        <class>.<function>, the class being the library file the equation comes from (where such functions
        are called)."""
        asts = _parse_list(strs, e["eqIndex"])
        prefix = self.model_name + "."
        if not self.model_name or not any(prefix in s for s in strs):
            return asts

        def rename(name):
            if not name.startswith(prefix) or name in LIBRARY:
                return name
            func = name.rsplit(".", 1)[1]
            for cls in _library_classes(e.get("source", {}).get("info", {}).get("file")):
                if f"{cls}.{func}" in LIBRARY:
                    return f"{cls}.{func}"
            return name
        return [_rename_calls(a, rename) for a in asts]

    def _blocks(self, section):
        eqs = [e for e in self.by_index.values() if e.get("section") == section]
        eqs.sort(key=lambda e: e["eqIndex"])
        children = {}
        for e in eqs:
            if "parent" in e:
                children.setdefault(e["parent"], []).append(e)
        out = []
        for e0 in eqs:
            if "parent" in e0:
                continue
            e = self._resolve(e0)
            tag = e["tag"]
            if tag in ("algorithm", "dummy"):
                continue  # asserts and the like
            if tag == "assign":
                defs = [canonical_der(d) for d in e["defines"]]
                out.append(Block(e0["eqIndex"], "assign", defs, self._parse(e["equation"], e)))
            elif tag == "system":
                if e.get("display") != "linear":
                    raise NotImplementedError(f"equation {e0['eqIndex']}: {e.get('display')} system")
                defs = [canonical_der(d) for d in e["defines"]]
                sysd = e["equation"][0]
                A = [(a["row"], a["column"], self._parse([a["exp"]], e)[0]) for a in sysd["A"]]
                b = self._parse([x if isinstance(x, str) else x["exp"] for x in sysd["b"]], e)
                blk = Block(e0["eqIndex"], "linear", defs, [a for _, _, a in A] + b)
                blk.A, blk.b, blk.n = A, b, sysd["size"]
                out.append(blk)
            elif tag == "tornsystem":
                if e.get("display") != "linear":
                    raise NotImplementedError(f"equation {e0['eqIndex']}: nonlinear torn system")
                kids = children.get(e0["eqIndex"], [])
                torn = [Block(c["eqIndex"], "assign", [canonical_der(d) for d in c["defines"]],
                              self._parse(c["equation"], c)) for c in kids if c["tag"] == "torn"]
                res = [self._parse(c["equation"][:1], c)[0] for c in kids if c["tag"] == "residual"]
                tear = [canonical_der(d) for d in e["defines"]]
                if len(res) != len(tear):
                    raise ValueError(f"torn system {e0['eqIndex']}: {len(res)} residuals for {len(tear)} tearing vars")
                blk = Block(e0["eqIndex"], "torn", tear + [d for t in torn for d in t.defines], res, torn)
                blk.tear, blk.torn, blk.res = tear, torn, res
                out.append(blk)
            else:
                raise NotImplementedError(f"equation {e0['eqIndex']}: tag {tag!r}")
        return out

    # ------------------------------------------------------------------------------------ slicing
    @staticmethod
    def _definers(blocks):
        definer, elements = {}, {}
        for b in blocks:
            for d in b.defines:
                definer[d] = b
                base = d.split("[")[0] if d.endswith("]") else None
                if base:
                    elements.setdefault(base, []).append(d)
        return definer, elements

    def _needed(self, blocks, targets, known):
        """Blocks (in order) that the targets depend on, and the names nothing defines."""
        definer, elements = self._definers(blocks)
        records = None  # record name -> its defined fields (a record passed whole, e.g. an Orientation)
        need, missing, stack, seen = set(), set(), list(targets), set()
        while stack:
            n = stack.pop()
            if n in seen or n in known:
                continue
            seen.add(n)
            if n in definer:
                b = definer[n]
                if id(b) not in need:
                    need.add(id(b))
                    stack.extend(b.uses)
            elif n in elements:  # whole-array reference
                stack.extend(elements[n])
            else:
                if records is None:
                    records = {}
                    for d in definer:
                        k = d.find(".")
                        while k != -1:
                            records.setdefault(d[:k], []).append(d)
                            k = d.find(".", k + 1)
                if n in records:  # whole-record reference
                    stack.extend(records[n])
                else:
                    missing.add(n)
        return [b for b in blocks if id(b) in need], missing

    # ------------------------------------------------------------------------------------ evaluation
    def _run(self, blocks, env, cuts=None, min_size=None):
        """Evaluate blocks in order into env. cuts: list collecting the linear systems of >= min_size
        unknowns that are left for a numeric solve: their solution becomes a placeholder symbol z and
        (z, J, r0) with J z + r0 = 0 is appended (see function()); None = solve every system symbolically."""
        lookup = lookup_in(env)

        def numeric(n):
            return cuts is not None and n >= min_size
        for b in blocks:
            if b.kind == "assign":
                val = evaluate(b.asts[0], lookup, LIBRARY)
                if len(b.defines) == 1:
                    env[b.defines[0]] = val
                else:
                    flat = np.asarray(val, dtype=object).ravel()
                    for d, v in zip(b.defines, flat):
                        env[d] = v
            elif b.kind == "linear":
                A = ca.SX(b.n, b.n)
                for i, j, a in b.A:
                    A[i, j] = evaluate(a, lookup, LIBRARY)
                rhs = ca.vertcat(*[evaluate(x, lookup, LIBRARY) for x in b.b])
                if numeric(b.n):
                    x = ca.SX.sym(f"lin{b.eq}", b.n)
                    cuts.append((x, A, -rhs))
                else:
                    x = ca.solve(A, rhs)
                for k, d in enumerate(b.defines):
                    env[d] = x[k]
            elif b.kind == "torn":
                z = ca.SX.sym("tear", len(b.tear))
                sub = dict(env)
                for k, d in enumerate(b.tear):
                    sub[d] = z[k]
                self._run(b.torn, sub)
                r = ca.vertcat(*[evaluate(a, lookup_in(sub), LIBRARY) for a in b.res])
                J = ca.jacobian(r, z)
                r0 = ca.substitute(r, z, ca.SX.zeros(z.shape))
                if ca.depends_on(J, z):
                    raise ValueError(f"torn system {b.eq} is not linear in its tearing variables")
                if numeric(len(b.tear)):
                    zs = ca.SX.sym(f"tear{b.eq}", len(b.tear))
                    cuts.append((zs, J, r0))
                else:
                    zs = -ca.solve(J, r0)
                for k, d in enumerate(b.tear):
                    env[d] = zs[k]
                for t in b.torn:
                    for d in t.defines:
                        env[d] = ca.substitute(ca.SX(sub[d]) if not isinstance(sub[d], ca.SX) else sub[d], z, zs)
        return env

    def _initialization(self, names, params):
        """Values of `names` from the initial section, evaluated the way the FMU initializes: inputs and
        states that have a start value (initial = exact, or unset) start there, everything else is computed."""
        if self._init_blocks is None:  # "start" defines $START.x from expressions; then initialization proper
            self._init_blocks = self._blocks("start") + self._blocks("initial")
        if not self.complete_start_values:
            warnings.warn("initialization without the FMU's _init_fmu.c: start values missing from "
                          "modelDescription.xml are taken as 0", stacklevel=3)
        # OMC's initial equations assign every unknown (fixed ones from $START.x); only the start values,
        # parameters and inputs are known beforehand
        env = dict(params)
        for n, val in self.start_values.items():
            env["$START." + n] = val
        for n in self.inputs:
            env.setdefault(n, self.start_values.get(n, 0.0))
        env.setdefault("time", 0.0)
        # pre(x) read by the dynamics = x at the last event; without events that is x after initialization
        targets = {n[len("$PRE."):] if n.startswith("$PRE.") else n for n in names}
        blocks, missing = self._needed(self._init_blocks, targets, set(env))
        missing = {m for m in missing if not _has(env, m)}
        # the initial section also reads calculated parameters: take those from the parameter section
        pblocks, _ = self._needed(self.param_blocks, missing, set(env))
        env = self._run(pblocks, env)
        missing = {m for m in missing if not _has(env, m)}
        for m in [m for m in missing if m.startswith(("$START.", "$PRE."))]:
            # pre(x) at initialization is x's start value; no start attribute: Modelica's default 0
            env[m] = env.get("$START." + m.split(".", 1)[1], 0.0)
            missing.discard(m)
        if missing:
            raise KeyError(f"initialization needs values for {sorted(missing)[:20]}")
        env = self._run(blocks, env)
        out = dict(params)
        for n in names:
            if n.startswith("$PRE."):
                out[n] = lookup_in(env)(n[len("$PRE."):])
            else:
                out.update({k: v for k, v in env.items() if k == n or k.startswith(n + "[")})
        return out

    # ------------------------------------------------------------------------------------ public
    def parameters(self, overrides=None, symbolic=()):
        """Values of every parameter the dynamics may need. symbolic: independent parameter names kept
        as SX symbols (returned in .param_syms) instead of numbers."""
        env = dict(self.start)
        unknown = set(overrides or {}) - set(self.start)
        if unknown:  # a calculated parameter would be silently recomputed by the parameter section
            raise KeyError(f"not independent parameters (cannot override): {sorted(unknown)}")
        env.update(overrides or {})
        self.param_syms = {}
        for n in symbolic:
            if n not in self.start:
                raise KeyError(f"{n} is not an independent parameter")
            env[n] = self.param_syms[n] = ca.SX.sym(n)
        return env

    def function(self, name="f", outputs=True, overrides=None, symbolic_params=(), states=None, inputs=None,
                 linear_solver=None, min_size=20):
        """CasADi Function f(x, u[, p]) -> (ode[, y]) in the FMU's state/input/output order, or the given ones.
        outputs: True = every FMU output, False = none (no y), or a list of output (or any variable) names."""
        states = list(self.states if states is None else states)
        inputs = list(self.inputs if inputs is None else inputs)
        ders = ["$DER." + s for s in states]
        outputs = list(self.outputs) if outputs is True else list(outputs or [])
        targets = ders + outputs

        x = ca.SX.sym("x", len(states))
        u = ca.SX.sym("u", len(inputs))
        env = {s: x[k] for k, s in enumerate(states)}
        env.update({n: u[k] for k, n in enumerate(inputs)})
        env["time"] = 0.0

        blocks, missing = self._needed(self.blocks, targets, set(env))
        # missing names must be parameters: compute the ones needed from the parameter section ...
        params = self.parameters(overrides, symbolic_params)
        pblocks, pmissing = self._needed(self.param_blocks, missing, set(params))
        # ... and the parameter section's own missing names (fixed=false parameters, computed during
        # initialization from start values, as the FMU does) from the initial section
        late = {m for m in set(missing) | pmissing if not _has(params, m) and m not in self._definers(pblocks)[0]}
        if late:
            params = self._initialization(late, params)
        # event memory used by the dynamics (e.g. which root of an analytic loop): frozen at its value
        # after initialization, as an FMU evaluated without event iteration does
        self.frozen_pre = sorted(m[len("$PRE."):] for m in late if m.startswith("$PRE."))
        if self.frozen_pre:
            warnings.warn(f"pre() of {self.frozen_pre} frozen at the initialization values (no events in the "
                          "converted model); valid while the model stays on that branch", stacklevel=2)
        params = self._run(pblocks, params)
        unresolved = [m for m in missing if not _has(params, m)]
        if unresolved:
            raise KeyError(f"no value for {sorted(unresolved)[:20]}")
        for m in missing:
            if m in params:
                env[m] = params[m]
            else:
                env.update({k: v for k, v in params.items() if k.startswith(m + "[")})
        self.used_blocks = blocks
        cuts = [] if linear_solver else None
        env = self._run(blocks, env, cuts, min_size)

        ode = ca.vertcat(*[env[d] for d in ders])
        args, names = [x, u], ["x", "u"]
        if self.param_syms:
            args.append(ca.vertcat(*self.param_syms.values()))
            names.append("p")
        outs, onames = [ode], ["ode"]
        if outputs:
            outs.append(ca.vertcat(*[env[y] for y in outputs]))
            onames.append("y")
        self.numeric_solves = [z.numel() for z, _, _ in cuts or []]
        if not cuts:
            return ca.Function(name, args, outs, names, onames)
        # MX function: each large system's (J, r0) is an SX function of the arguments and the earlier
        # systems' solutions, solved numerically (pivoted LU); the rest is one SX function of all of them.
        # CasADi differentiates through the solves exactly: dz = -J \ (dr0 + dJ z).
        zs = [z for z, _, _ in cuts]
        margs = [ca.MX.sym(nm, a.sparsity()) for a, nm in zip(args, names)]
        zm = []
        for k, (_, J, r0) in enumerate(cuts):
            sysk = ca.Function(f"{name}_sys{k}", args + zs[:k], [J, r0])
            Jm, rm = sysk(*margs, *zm)
            zm.append(-ca.solve(Jm, rm, linear_solver))
        post = ca.Function(f"{name}_post", args + zs, outs)
        return ca.Function(name, margs, post(*margs, *zm), names, onames)


def _start_value(typ):
    s = typ.get("start")
    if typ.tag == "Boolean":
        return s == "true"
    if typ.tag in ("Integer", "Enumeration"):
        return int(s)
    if typ.tag == "Real":
        return float(s)
    return s


_INIT_NAME = re.compile(r'(\w+)Data\[(\d+)\]\.info\.name = "((?:[^"\\]|\\.)*)";')
_INIT_START = re.compile(r'(\w+)Data\[(\d+)\]\.attribute\.start = ([^;]*);')


def _init_fmu_starts(src):
    """{name: start value} from OMC's generated <model>_init_fmu.c (realVarsData[i].info.name / .attribute.start)."""
    if hasattr(src, "read"):
        text = src.read()
        text = text.decode("utf-8", "replace") if isinstance(text, bytes) else text
    else:
        with open(src, encoding="utf-8", errors="replace") as f:
            text = f.read()
    names = {(m.group(1), m.group(2)): m.group(3).replace('\\"', '"') for m in _INIT_NAME.finditer(text)}
    out = {}
    for m in _INIT_START.finditer(text):
        name = names.get((m.group(1), m.group(2)))
        raw = m.group(3).strip()
        if name is None or raw.startswith('"'):
            continue
        try:
            val = float(raw.replace("DBL_MAX", "inf"))
        except ValueError:
            continue
        kind = m.group(1)
        out[name] = (val != 0) if kind.startswith("boolean") else int(val) if kind.startswith("integer") else val
    return out


def _has(env, name):
    return name in env or any(k.startswith((name + "[", name + ".")) for k in env)


def lookup_in(env):
    def lookup(name):
        try:
            return env[name]
        except KeyError:
            els = [k for k in env if k.startswith(name + "[")]
            if not els:
                # a record passed whole: its fields (scalars or arrays) by name
                fields = {re.split(r"[.\[]", k[len(name) + 1:], 1)[0] for k in env if k.startswith(name + ".")}
                if not fields:
                    raise
                return Record({f: lookup(f"{name}.{f}") for f in fields})
            idx = [tuple(int(i) for i in k[len(name) + 1:-1].split(",")) for k in els]
            shape = tuple(max(ix[d] for ix in idx) for d in range(len(idx[0])))
            arr = np.empty(shape, dtype=object)
            for k, ix in zip(els, idx):
                arr[tuple(i - 1 for i in ix)] = env[k]
            return arr
    return lookup
