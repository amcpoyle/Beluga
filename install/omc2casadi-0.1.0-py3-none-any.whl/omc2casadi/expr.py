"""Parser and evaluator for the Modelica expressions OMC writes into <model>_info.json.

parse(text) -> AST of plain tuples:
    ("num", value)  ("bool", value)  ("str", text)
    ("name", canonical)                 scalarized name with literal subscripts folded in, e.g. "a.R.T[3,2]";
                                        der(x) is the name "$DER.x", as OMC writes it in expressions, and
                                        pre(x) the name "$PRE.x"
    ("index", expr, [subscript exprs])  subscript on anything that is not a plain name
    ("call", function, [args])
    ("un", op, a)  ("bin", op, a, b)
    ("if", [(cond, expr), ...], else_expr)
    ("array", [items])  ("matrix", [[items], ...])

evaluate(ast, lookup, functions) works on Python floats, CasADi SX scalars and numpy object arrays of
either (Modelica arrays), so the same code computes parameters numerically and the dynamics symbolically.
"""
import math
import re

import casadi as ca
import numpy as np

_TOKEN = re.compile(r"""
    (?P<ws>\s+|/\*.*?\*/|//[^\n]*)
  | (?P<num>(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)
  | (?P<str>"(?:[^"\\]|\\.)*")
  | (?P<ident>[A-Za-z_$][\w$]*|'(?:[^'\\]|\\.)*')
  | (?P<op>\.\^|\.\*|\./|\.\+|\.-|<=|>=|==|<>|:=|[()\[\]{},;:.+\-*/^<>=])
""", re.VERBOSE)

KEYWORDS = {"if", "then", "elseif", "else", "and", "or", "not", "true", "false"}


def tokenize(text):
    out, pos = [], 0
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m:
            raise SyntaxError(f"cannot tokenize at {pos}: {text[pos:pos + 40]!r}")
        pos = m.end()
        kind = m.lastgroup
        if kind == "ws":
            continue
        val = m.group()
        if kind == "ident" and val in KEYWORDS:
            kind = "kw"
        out.append((kind, val))
    out.append(("end", None))
    return out


class _Parser:
    def __init__(self, text):
        self.text, self.tok, self.i = text, tokenize(text), 0

    def peek(self, k=0):
        return self.tok[self.i + k]

    def next(self):
        t = self.tok[self.i]
        self.i += 1
        return t

    def accept(self, val):
        if self.tok[self.i][1] == val and self.tok[self.i][0] in ("op", "kw"):
            self.i += 1
            return True
        return False

    def expect(self, val):
        if not self.accept(val):
            raise SyntaxError(f"expected {val!r} at token {self.i} {self.peek()} in {self.text[:200]!r}")

    def parse(self):
        e = self.expression()
        if self.peek()[0] != "end":
            raise SyntaxError(f"trailing input at token {self.i} {self.peek()} in {self.text[:200]!r}")
        return e

    def expression(self):
        if self.accept("if"):
            branches = [(self.expression(), None)]
            self.expect("then")
            branches[0] = (branches[0][0], self.expression())
            while self.accept("elseif"):
                c = self.expression()
                self.expect("then")
                branches.append((c, self.expression()))
            self.expect("else")
            return ("if", branches, self.expression())
        return self.logical_or()

    def logical_or(self):
        a = self.logical_and()
        while self.accept("or"):
            a = ("bin", "or", a, self.logical_and())
        return a

    def logical_and(self):
        a = self.logical_not()
        while self.accept("and"):
            a = ("bin", "and", a, self.logical_not())
        return a

    def logical_not(self):
        if self.accept("not"):
            return ("un", "not", self.relation())
        return self.relation()

    def relation(self):
        a = self.arithmetic()
        t = self.peek()
        if t[0] == "op" and t[1] in ("<", "<=", ">", ">=", "==", "<>"):
            self.next()
            return ("bin", t[1], a, self.arithmetic())
        return a

    def arithmetic(self):
        t = self.peek()
        if t[0] == "op" and t[1] in ("+", "-", ".+", ".-"):
            self.next()
            a = self.term()
            a = ("un", "-", a) if t[1] in ("-", ".-") else a
        else:
            a = self.term()
        while True:
            t = self.peek()
            if t[0] == "op" and t[1] in ("+", "-", ".+", ".-"):
                self.next()
                a = ("bin", t[1].lstrip("."), a, self.term())
            else:
                return a

    def term(self):
        a = self.factor()
        while True:
            t = self.peek()
            if t[0] == "op" and t[1] in ("*", "/", ".*", "./"):
                self.next()
                a = ("bin", t[1], a, self.factor())
            else:
                return a

    def factor(self):
        a = self.postfix()
        t = self.peek()
        if t[0] == "op" and t[1] in ("^", ".^"):
            self.next()
            # OMC parenthesizes negative exponents, but accept a unary sign anyway
            if self.peek()[1] in ("-", "+") and self.peek()[0] == "op":
                sign = self.next()[1]
                b = self.postfix()
                b = ("un", "-", b) if sign == "-" else b
            else:
                b = self.postfix()
            return ("bin", t[1], a, b)
        return a

    def postfix(self):
        a = self.primary()
        while self.peek() == ("op", "["):
            self.next()
            a = ("index", a, self.subscripts())
        return a

    def subscripts(self):
        subs = [self.expression()]
        while self.accept(","):
            subs.append(self.expression())
        self.expect("]")
        return subs

    def primary(self):
        kind, val = self.next()
        if kind == "num":
            return ("num", float(val)) if any(c in val for c in ".eE") else ("num", int(val))
        if kind == "str":
            return ("str", val[1:-1])
        if kind == "kw" and val in ("true", "false"):
            return ("bool", val == "true")
        if kind == "op" and val == "(":
            e = self.expression()
            if self.accept(","):  # tuple, only appears in multi-output calls; not supported further
                raise SyntaxError("tuple expressions are not supported")
            self.expect(")")
            return e
        if kind == "op" and val == "{":
            items = [] if self.peek() == ("op", "}") else [self.expression()]
            while self.accept(","):
                items.append(self.expression())
            self.expect("}")
            return ("array", items)
        if kind == "op" and val == "[":
            rows, row = [], [self.expression()]
            while True:
                if self.accept(","):
                    row.append(self.expression())
                elif self.accept(";"):
                    rows.append(row)
                    row = [self.expression()]
                else:
                    self.expect("]")
                    rows.append(row)
                    return ("matrix", rows)
        if kind == "ident":
            return self.name_or_call(val)
        raise SyntaxError(f"unexpected {val!r} at token {self.i - 1} in {self.text[:200]!r}")

    def name_or_call(self, first):
        parts, dynamic = [first], []
        while True:
            t = self.peek()
            if t == ("op", ".") and self.peek(1)[0] == "ident":
                self.next()
                parts.append("." + self.next()[1])
            elif t == ("op", "[") and not dynamic:
                save = self.i
                self.next()
                subs = self.subscripts()
                if all(s[0] == "num" and isinstance(s[1], int) for s in subs):
                    parts.append("[" + ",".join(str(s[1]) for s in subs) + "]")
                else:  # non-literal subscript: index the array value instead
                    self.i = save
                    break
            else:
                break
        name = "".join(parts)
        if self.peek() == ("op", "("):
            self.next()
            args = []
            if not self.accept(")"):
                args.append(self.call_arg())
                while self.accept(","):
                    args.append(self.call_arg())
                self.expect(")")
            if name == "der" and len(args) == 1 and args[0][0] == "name":
                return ("name", "$DER." + args[0][1])
            if name == "pre" and len(args) == 1 and args[0][0] == "name":
                return ("name", "$PRE." + args[0][1])  # value at the last event: only known at initialization
            return ("call", name, args)
        return ("name", name)

    def call_arg(self):
        # named arguments (f(x, n = 2)) only appear in asserts/String(); keep the value
        if self.peek()[0] == "ident" and self.peek(1) == ("op", "="):
            self.next()
            self.next()
        return self.expression()


def parse(text):
    return _Parser(text).parse()


def canonical_der(name):
    """'der(der(x))' -> '$DER.$DER.x'; any other name unchanged."""
    prefix = ""
    while name.startswith("der(") and name.endswith(")"):
        prefix, name = prefix + "$DER.", name[4:-1]
    return prefix + name


def free_names(ast, out=None):
    """All ("name", n) leaves of an AST."""
    out = set() if out is None else out
    tag = ast[0]
    if tag == "name":
        out.add(ast[1])
    elif tag == "index":
        free_names(ast[1], out)
        for s in ast[2]:
            free_names(s, out)
    elif tag == "call":
        for a in ast[2]:
            free_names(a, out)
    elif tag == "un":
        free_names(ast[2], out)
    elif tag == "bin":
        free_names(ast[2], out)
        free_names(ast[3], out)
    elif tag == "if":
        for c, e in ast[1]:
            free_names(c, out)
            free_names(e, out)
        free_names(ast[2], out)
    elif tag == "array":
        for e in ast[1]:
            free_names(e, out)
    elif tag == "matrix":
        for row in ast[1]:
            for e in row:
                free_names(e, out)
    return out


# ---------------------------------------------------------------------------------------- evaluation

def _sym(x):
    return isinstance(x, (ca.SX, ca.MX))


def _unary(np_fun, ca_fun):
    def f(x):
        if isinstance(x, np.ndarray):
            return np.vectorize(f, otypes=[object])(x)
        return ca_fun(x) if _sym(x) else np_fun(x)
    return f


def _as_array(x):
    return x if isinstance(x, np.ndarray) else None


def _mul(a, b):
    A, B = _as_array(a), _as_array(b)
    if A is None or B is None:
        return a * b
    if A.ndim == 1 and B.ndim == 1:
        return sum(A[i] * B[i] for i in range(A.shape[0]))
    return np.dot(A, B)


def _logic(op, a, b=None):
    if op == "not":
        return ca.logic_not(a) if _sym(a) else (not a)
    if _sym(a) or _sym(b):
        return ca.logic_and(a, b) if op == "and" else ca.logic_or(a, b)
    return (a and b) if op == "and" else (a or b)


def _rel(op, a, b):
    if op == "<":
        return a < b
    if op == "<=":
        return a <= b
    if op == ">":
        return a > b
    if op == ">=":
        return a >= b
    if op == "==":
        return a == b
    return a != b


def _if(cond, a, b):
    if _sym(cond):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            return np.vectorize(lambda x, y: ca.if_else(cond, x, y), otypes=[object])(a, b)
        return ca.if_else(cond, a, b)
    return a if cond else b


def objarray(items):
    """numpy object array from a list of scalars or equally shaped arrays. np.array(list) would try to
    iterate CasADi SX elements."""
    if items and isinstance(items[0], np.ndarray):
        out = np.empty((len(items),) + items[0].shape, dtype=object)
    else:
        out = np.empty(len(items), dtype=object)
    for i, it in enumerate(items):
        out[i] = it
    return out


def _promote(x, n):
    x = x if isinstance(x, np.ndarray) else objarray([x])[0:1].reshape(())
    while x.ndim < int(n):
        x = x[..., None]
    return x


def _minmax(fun_np, fun_ca):
    def f(*args):
        if len(args) == 1:  # min/max over an array
            vals = list(np.asarray(args[0], dtype=object).ravel())
        else:
            vals = list(args)
        out = vals[0]
        for v in vals[1:]:
            out = fun_ca(out, v) if (_sym(out) or _sym(v)) else fun_np(out, v)
        return out
    return f


BUILTINS = {
    "sin": _unary(math.sin, ca.sin), "cos": _unary(math.cos, ca.cos), "tan": _unary(math.tan, ca.tan),
    "asin": _unary(math.asin, ca.asin), "acos": _unary(math.acos, ca.acos), "atan": _unary(math.atan, ca.atan),
    "sinh": _unary(math.sinh, ca.sinh), "cosh": _unary(math.cosh, ca.cosh), "tanh": _unary(math.tanh, ca.tanh),
    "exp": _unary(math.exp, ca.exp), "log": _unary(math.log, ca.log), "log10": _unary(math.log10, ca.log10),
    "sqrt": _unary(math.sqrt, ca.sqrt), "abs": _unary(abs, ca.fabs),
    "sign": _unary(lambda x: float(np.sign(x)), ca.sign),
    "$_signNoNull": _unary(lambda x: 1.0 if x >= 0 else -1.0, lambda x: ca.if_else(x >= 0, 1, -1)),  # OMC: sign, +1 at 0
    "floor": _unary(math.floor, ca.floor), "ceil": _unary(math.ceil, ca.ceil),
    "atan2": lambda y, x: ca.atan2(y, x) if (_sym(y) or _sym(x)) else math.atan2(y, x),
    "min": _minmax(min, ca.fmin), "max": _minmax(max, ca.fmax),
    "noEvent": lambda x: x, "smooth": lambda n, x: x, "homotopy": lambda actual, simplified: actual,
    "integer": lambda x: int(x), "Integer": lambda x: int(x), "Real": lambda x: x,
    "transpose": lambda x: np.asarray(x, dtype=object).T, "promote": _promote,
    "semiLinear": lambda x, kp, kn: _if(x >= 0, kp * x, kn * x),
}


def evaluate(ast, lookup, functions=None):
    """lookup(name) -> value; functions: extra {name: python callable} (Modelica library functions)."""
    def ev(a):
        tag = a[0]
        if tag == "num" or tag == "bool" or tag == "str":
            return a[1]
        if tag == "name":
            return lookup(a[1])
        if tag == "bin":
            op = a[1]
            if op in ("and", "or"):
                return _logic(op, ev(a[2]), ev(a[3]))
            x, y = ev(a[2]), ev(a[3])
            if op == "+":
                return x + y
            if op == "-":
                return x - y
            if op == "*":
                return _mul(x, y)
            if op in ("/", "./"):
                return x / y
            if op == ".*":
                return x * y
            if op in ("^", ".^"):
                if isinstance(y, int) and not _sym(x) and not isinstance(x, np.ndarray):
                    return float(x) ** y
                return x ** y
            return _rel(op, x, y)
        if tag == "un":
            x = ev(a[2])
            return _logic("not", x) if a[1] == "not" else -x
        if tag == "if":
            # evaluate from the last branch backwards so nested if_else nests the same way
            out = ev(a[2])
            for cond, val in reversed(a[1]):
                c = ev(cond)
                if not _sym(c):
                    out = ev(val) if c else out
                else:
                    out = _if(c, ev(val), out)
            return out
        if tag == "call":
            f = (functions or {}).get(a[1]) or BUILTINS.get(a[1])
            if f is None:
                raise NotImplementedError(f"function {a[1]!r} has no implementation")
            return f(*[ev(x) for x in a[2]])
        if tag == "index":
            v = np.asarray(ev(a[1]), dtype=object)
            return v[tuple(int(ev(s)) - 1 for s in a[2])]
        if tag == "array":
            return objarray([ev(x) for x in a[1]])
        if tag == "matrix":
            return objarray([objarray([ev(x) for x in row]) for row in a[1]])
        raise ValueError(f"unknown AST node {tag}")
    return ev(ast)
