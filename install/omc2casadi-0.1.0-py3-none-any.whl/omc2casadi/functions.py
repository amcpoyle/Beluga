"""CasADi/numpy implementations of the Modelica library functions OMC leaves as calls in the solved
equations (it inlines most). Arrays are numpy object arrays, as in expr.evaluate; each function follows
the MSL 4.0.0 source line by line (conditions through expr._if, so they work on floats and SX alike).

A function used by a model but missing here stops the conversion with "function ... has no
implementation"; add it here, then re-run the FMU check.
"""
import numpy as np

from .expr import BUILTINS, _if, _logic, objarray

_sqrt, _abs = BUILTINS["sqrt"], BUILTINS["abs"]
_sin, _cos, _atan2 = BUILTINS["sin"], BUILTINS["cos"], BUILTINS["atan2"]
EPS = 2.220446049250313e-16  # Modelica.Constants.eps


def _vec(v):
    return v if isinstance(v, np.ndarray) else objarray(list(v))


def _dot(a, b):
    return sum(a[i] * b[i] for i in range(len(a)))


def cross(x, y):
    return objarray([x[1] * y[2] - x[2] * y[1], x[2] * y[0] - x[0] * y[2], x[0] * y[1] - x[1] * y[0]])


def skew(x):
    return objarray([objarray([0.0, -x[2], x[1]]), objarray([x[2], 0.0, -x[0]]), objarray([-x[1], x[0], 0.0])])


def length(v):
    return _sqrt(_dot(v, v))


def normalize(v, eps=100 * EPS):
    # smooth(0, if length(v) >= eps then v/length(v) else v/eps)
    n = length(v)
    return _if(n >= eps, v / n, v / eps)


def from_nxy(n_x, n_y):
    """Frames.TransformationMatrices.from_nxy: 3x3 transformation matrix T from frame 1 to frame 2."""
    n_x, n_y = _vec(n_x), _vec(n_y)
    e_x = _if(length(n_x) < 1e-10, objarray([1.0, 0.0, 0.0]), normalize(n_x))
    e_y = _if(length(n_y) < 1e-10, objarray([0.0, 1.0, 0.0]), normalize(n_y))
    n_z_aux = cross(e_x, e_y)
    n_y_aux = _if(_dot(n_z_aux, n_z_aux) > 1.0e-6, e_y,
                  _if(_abs(e_x[0]) > 1.0e-6, objarray([0.0, 1.0, 0.0]), objarray([1.0, 0.0, 0.0])))
    e_z = normalize(cross(e_x, n_y_aux))
    return objarray([e_x, cross(e_z, e_x), e_z])


class Record(dict):
    """Modelica record value; fields by name (R["T"])."""


def orientation(T, w):
    return Record(T=np.asarray(T, dtype=object), w=_vec(w))


def _T(R):
    return R["T"] if isinstance(R, Record) else np.asarray(R, dtype=object)


def _mv(M, v):
    return objarray([sum(M[i, j] * v[j] for j in range(M.shape[1])) for i in range(M.shape[0])])


def resolve2(R, v1):
    return _mv(_T(R), _vec(v1))


def resolve1(R, v2):
    return _mv(_T(R).T, _vec(v2))


def norm(v, p=2.0):
    """Math.Vectors.norm: p-norm (p = 1, 2, inf or any p >= 1)."""
    v, eps = _vec(v), 10 * EPS
    if len(v) == 0:
        return 0.0
    if 2 - eps <= p <= 2 + eps:
        return _sqrt(_dot(v, v))
    if p == float("inf"):
        return BUILTINS["max"](BUILTINS["abs"](v))
    if 1 - eps <= p <= 1 + eps:
        return sum(_abs(x) for x in v)
    if p >= 1:
        return sum(_abs(x) ** p for x in v) ** (1 / p)
    raise ValueError(f"Vectors.norm: p = {p} < 1")


def _axis(k):
    return objarray([1.0 if int(k) == i else 0.0 for i in (1, 2, 3)])


def planar_rotation(e, angle):
    """Frames.TransformationMatrices.planarRotation: T of a rotation by angle about unit axis e."""
    e = _vec(e)
    ee = np.array([[e[i] * e[j] for j in range(3)] for i in range(3)], dtype=object)
    eye = np.array([[1.0 if i == j else 0.0 for j in range(3)] for i in range(3)], dtype=object)
    return ee + (eye - ee) * _cos(angle) - skew(e) * _sin(angle)


def planar_rotation_angle(e, v1, v2):
    """Frames.planarRotationAngle: angle about e that rotates v1 (frame 1) into v2 (frame 2)."""
    e, v1, v2 = _vec(e), _vec(v1), _vec(v2)
    return _atan2(-_dot(cross(e, v1), v2), _dot(v1, v2) - _dot(e, v1) * _dot(e, v2))


def axes_rotations_angles(R, sequence=(1, 2, 3), guess_angle1=0.0):
    """Frames.axesRotationsAngles: the 3 angles about axes `sequence` that construct orientation R."""
    T = _T(R)
    e1_1, e2_1a, e3_2 = _axis(sequence[0]), _axis(sequence[1]), _axis(sequence[2])
    e3_1 = T[int(sequence[2]) - 1, :]
    A = _dot(e2_1a, e3_1)
    B = _dot(cross(e1_1, e2_1a), e3_1)
    angle_1a = _atan2(A, -B)
    angle_1b = _atan2(-A, B)
    a1 = _if(_abs(angle_1a - guess_angle1) <= _abs(angle_1b - guess_angle1), angle_1a, angle_1b)
    a1 = _if(_logic("and", _abs(A) <= 1e-12, _abs(B) <= 1e-12), guess_angle1, a1)
    T_1a = planar_rotation(e1_1, a1)
    a2 = planar_rotation_angle(e2_1a, _mv(T_1a, e3_1), e3_2)
    a3 = planar_rotation_angle(e3_2, e2_1a, _mv(T, _mv(T_1a.T, e2_1a)))
    return objarray([a1, a2, a3])


def select_branch(L, e, angle_guess, r_a, r_b):
    """Joints.Internal.RevoluteWithLengthConstraint.selectBranch: true if the "positive" root of the
    length constraint is the one closer to angle_guess (the assert on a singular loop is left out)."""
    e, r_a, r_b = _vec(e), _vec(r_a), _vec(r_b)
    e_r_a, e_r_b = _dot(e, r_a), _dot(e, r_b)
    A = -2 * (_dot(r_b, r_a) - e_r_b * e_r_a)
    B = 2 * _dot(r_b, cross(e, r_a))
    C = _dot(r_a, r_a) + _dot(r_b, r_b) - L * L - 2 * e_r_b * e_r_a
    k1 = A * A + B * B
    k1a = k1 - C * C
    k1b = BUILTINS["max"](k1a, 1.0e-12)
    k2 = _sqrt(k1b)
    angle1 = _atan2(-B * C - A * k2, -A * C + B * k2)
    angle2 = _atan2(-B * C + A * k2, -A * C - B * k2)
    return _abs(angle1 - angle_guess) <= _abs(angle2 - angle_guess)


def max_without_event(u1, u2):
    return _if(u1 > u2, u1, u2)


def max_without_event_d(u1, u2, u1_d, u2_d):
    return _if(u1 > u2, u1_d, u2_d)


def max_without_event_dd(u1, u2, u1_d, u2_d, u1_dd, u2_dd):
    return _if(u1 > u2, u1_dd, u2_dd)


def _filled(shape, value):
    out = np.empty(shape, dtype=object)
    out.fill(value)
    return out


# Modelica built-in array functions (unqualified names)
BUILTIN_ARRAYS = {
    "cross": cross, "skew": skew,
    "identity": lambda n: np.array([[1.0 if i == j else 0.0 for j in range(int(n))] for i in range(int(n))], dtype=object),
    "zeros": lambda *dims: _filled(tuple(int(d) for d in dims), 0.0),
    "ones": lambda *dims: _filled(tuple(int(d) for d in dims), 1.0),
    "fill": lambda value, *dims: _filled(tuple(int(d) for d in dims), value),
    "sum": lambda a: sum(np.asarray(a, dtype=object).ravel()),
    "product": lambda a: np.prod(np.asarray(a, dtype=object).ravel()),
    "diagonal": lambda v: np.array([[v[i] if i == j else 0.0 for j in range(len(v))] for i in range(len(v))], dtype=object),
    "outerProduct": lambda a, b: np.array([[a[i] * b[j] for j in range(len(b))] for i in range(len(a))], dtype=object),
    "scalar": lambda a: np.asarray(a, dtype=object).ravel()[0],
    "vector": lambda a: np.asarray(a, dtype=object).ravel(),
}

_FRAMES = "Modelica.Mechanics.MultiBody.Frames."
LIBRARY = dict(BUILTIN_ARRAYS, **{
    "Modelica.Math.Vectors.length": length,
    "Modelica.Math.Vectors.normalize": normalize,
    "Modelica.Math.Vectors.norm": norm,
    _FRAMES + "axesRotationsAngles": axes_rotations_angles,
    _FRAMES + "planarRotationAngle": planar_rotation_angle,
    _FRAMES + "TransformationMatrices.planarRotation": planar_rotation,
    _FRAMES + "TransformationMatrices.from_nxy": from_nxy,
    _FRAMES + "Orientation": orientation,
    _FRAMES + "resolve1": resolve1,
    _FRAMES + "resolve2": resolve2,
    _FRAMES + "TransformationMatrices.resolve1": resolve1,
    _FRAMES + "TransformationMatrices.resolve2": resolve2,
    _FRAMES + "Internal.maxWithoutEvent": max_without_event,
    _FRAMES + "Internal.maxWithoutEvent_d": max_without_event_d,
    _FRAMES + "Internal.maxWithoutEvent_dd": max_without_event_dd,
    # functions declared inside a model class; OmcModel maps OMC's instance-qualified names onto these
    "Modelica.Mechanics.MultiBody.Joints.Internal.RevoluteWithLengthConstraint.selectBranch": select_branch,
})
